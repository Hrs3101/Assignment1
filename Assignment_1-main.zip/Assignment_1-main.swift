func myfunc(a:Int)
{
  if a<0 {
    print("error")
  }
  else 
  {
    if a%2==0
    {
      print("Number is Even")
    }
    else
    {
      print("Number is Odd")
    }
  
   
  }
  
}

myfunc(a:4)